package parallel;

import org.testng.Assert;

import com.pages.AddUserPage;
import com.pages.AdminLoginPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminLoginSteps {

	private static String title;
	private AdminLoginPage AdminloginPage = new AdminLoginPage(DriverFactory.getDriver());
	
    private AddUserPage addNewUser;
    
    
	@Given("Open Login Page")
	public void open_login_page() {
	    
		DriverFactory.getDriver()
		.get("https://opensource-demo.orangehrmlive.com/");
System.out.println("user is on login page");
	}

	@When("Enter Username {string} and Password {string}")
	public void enter_username_and_password(String username, String password) {
	
		AdminloginPage.enterUserName(username);
		AdminloginPage.enterPassword(password);
		AdminloginPage.btnlogin();
		
	}

	@Then("Successful Login and Validate Title")
	public void successful_login_and_validate_title() {
	    
		Assert.assertEquals("OrangeHRM", AdminloginPage.getHomePageTitle());
		this.addNewUser = new AddUserPage(DriverFactory.getDriver());
	}
	


	
}
