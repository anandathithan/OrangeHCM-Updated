package parallel;

import org.testng.Assert;

import com.pages.AddUserPage;
import com.pages.AdminLoginPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddUserSteps {

	private static String title;
	private AddUserPage adduserPage = new AddUserPage(DriverFactory.getDriver());


	@Given("Navigate to Users Page")
	public void navigate_to_users_page() {
		adduserPage.NaviateToUsersPage();
	}

	@When("Add a User with his details")
	public void add_a_user_with_his_details() {
		adduserPage.createUser();
	}

	@Then("Validate User is created")
	public void validate_user_is_created() {
	   
	}

}
